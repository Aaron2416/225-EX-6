package com.zybooks.woodcalc;

import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private EditText lengthOfDeskEditText;
    private EditText widthOfDeskEditText;
    private RadioGroup woodTypeRadioGroup;
    private RadioButton selectedWoodTypeRadioButton;
    private EditText numDrawersEditText;
    private TextView priceTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lengthOfDeskEditText = findViewById(R.id.editTextLengthOfDesk);
        widthOfDeskEditText = findViewById(R.id.editTextWidthOfDesk);
        woodTypeRadioGroup = findViewById(R.id.radioGroupWoodType);
        numDrawersEditText = findViewById(R.id.editTextNumDrawers);
        priceTextView = findViewById(R.id.textViewPrice);

        Button calculateButton = findViewById(R.id.buttonCalculate);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int lengthOfDesk = Integer.parseInt(lengthOfDeskEditText.getText().toString());
                int widthOfDesk = Integer.parseInt(widthOfDeskEditText.getText().toString());
                int numDrawers = Integer.parseInt(numDrawersEditText.getText().toString());

                int selectedWoodTypeRadioButtonId = woodTypeRadioGroup.getCheckedRadioButtonId();
                selectedWoodTypeRadioButton = findViewById(selectedWoodTypeRadioButtonId);
                String woodType = selectedWoodTypeRadioButton.getText().toString();

                WoodCalc woodCalc = new WoodCalc(1, "", lengthOfDesk, widthOfDesk, woodType, numDrawers);
                int price = woodCalc.getPrice();
                priceTextView.setText("$" + price);
            }
        });
    }
}
